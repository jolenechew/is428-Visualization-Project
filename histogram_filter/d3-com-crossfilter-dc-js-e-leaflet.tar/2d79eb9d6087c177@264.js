// https://observablehq.com/@tomascco/d3-com-crossfilter-dc-js-e-leaflet@264
function _1(md){return(
md`# D3 com Crossfilter, DC.js e Leaflet`
)}

function _buildvis(md,container,dc,width,dateDimension,format,d3,magnitudeDimension,magnitudeGroup,magnitudeScale,depthDimension,depthGroup,depthScale,hourDimension,hourGroup,hourScale)
{
  let view = md`${container()}`

  let tableChart = dc.dataTable(view.querySelector('#dc-table-graph'));
  tableChart
    .width(width)
    .height(800)
    .dimension(dateDimension)
    .group(d => 'List of all earthquakes corresponding to the filters')
    .size(5)
    .columns([
      'dtg',
      {label: 'Maginitude', format: d => format(d.magnitude)},
      'depth',
      'latitude',
      'longitude'
    ])
    .sortBy(d => d.dtg)
    .order(d3.ascending);

  let magnitudeBarChart = dc.barChart(view.querySelector('#magnitude-chart'));
  magnitudeBarChart
    .width(360)
    .height(150)
    .margins({top: 10, right: 20, bottom: 20, left:30})
    .dimension(magnitudeDimension)
    .group(magnitudeGroup)
    .gap(70)
    .x(magnitudeScale)
    .elasticY(true)
    .centerBar(true)
    .renderHorizontalGridLines(true);

  let depthBarChart = dc.barChart(view.querySelector('#depth-chart'));
  depthBarChart
    .width(360)
    .height(150)
    .margins({top: 10, right: 10, bottom: 20, left:30})
    .dimension(depthDimension)
    .group(depthGroup)
    .x(depthScale)
    .elasticY(true)
    .centerBar(true)
    .renderHorizontalGridLines(true);

  let timeLineChart = dc.lineChart(view.querySelector('#time-chart'));
  timeLineChart
    .width(800)
    .height(150)
    .margins({top: 10, right: 10, bottom: 20, left:40})
    .dimension(hourDimension)
    .group(hourGroup)
    .x(hourScale)
    .elasticY(true)
    .brushOn(false)
    .renderHorizontalGridLines(true)
    .renderArea(false);

  dc.renderAll();
  return view
}


function _dataset(d3){return(
d3.csv('https://gist.githubusercontent.com/emanueles/301057974a02cf8446e42c1e46c9c742/raw/0ed6d119afbc5eeddc7f763d3708fc1829d22c9f/earthquakes.csv').then(data => {
  data.forEach(item => {
    item.dtg = d3.isoParse(item.origintime);
    
    item.magnitude = parseFloat(item.magnitude);
    
    item.depth = parseInt(item.depth, 10);
  })

  return data;
})
)}

function _facts(crossfilter,dataset){return(
crossfilter(dataset)
)}

function _5(md){return(
md`## Table`
)}

function _dateDimension(facts){return(
facts.dimension(d => d.dtg)
)}

function _format(d3){return(
d3.format('.1f')
)}

function _8(md){return(
md`## Magnitude`
)}

function _magnitudeDimension(facts){return(
facts.dimension(d => Math.round((d.magnitude + Number.EPSILON) * 10) / 10)
)}

function _magnitudeGroup(magnitudeDimension){return(
magnitudeDimension.group()
)}

function _magnitudeScale(d3,magnitudeDimension){return(
d3
  .scaleLinear()
  .domain([0, Math.round((magnitudeDimension.top(1)[0].magnitude + Number.EPSILON) * 10) / 10])
)}

function _12(md){return(
md`## Depth`
)}

function _depthDimension(facts){return(
facts.dimension(d => d.depth)
)}

function _depthGroup(depthDimension){return(
depthDimension.group()
)}

function _depthScale(d3,depthDimension){return(
d3.scaleLinear().domain([0, depthDimension.top(1)[0].depth])
)}

function _16(md){return(
md`## Time`
)}

function _hourDimension(facts,d3){return(
facts.dimension(d => d3.timeHour(d.dtg))
)}

function _hourGroup(hourDimension){return(
hourDimension.group()
)}

function _hourScale(d3,dataset){return(
d3.scaleTime()
  .domain(d3.extent(dataset, d => d.dtg))
)}

function _20(md){return(
md`## Map`
)}

function _map(buildvis,L)
{
  buildvis;

  let mapInstance = L.map('earthquake-map').setView([-41.05,172.93], 5)
  L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="http://www.openstreetmap.org/">OpenStreetMap</a> contributors',
    maxZoom: 17
  }).addTo(mapInstance)

  return mapInstance
}


function _circlesLayer(L,map){return(
L.layerGroup().addTo(map)
)}

function _mapMagnitudeScale(d3,magnitudeDimension){return(
d3.scaleLinear()
  .domain([0, magnitudeDimension.top(1)[0].magnitude])
  .range([0, 50000])
)}

function _circles(circlesLayer,dataset,L,mapMagnitudeScale,format)
{
  circlesLayer.clearLayers()
  dataset.forEach( function(d) {
    let circle = L.circle([d.latitude, d.longitude], mapMagnitudeScale(d.magnitude), {
      color: '#fd8d3c',
      weight: 1,
      fillColor: '#fecc5c',
      fillOpacity: 0.5
    })

    circle.bindPopup(`Magnitude: ${format(d.magnitude)}<br>Time: ${d.dtg}`)

    circlesLayer.addLayer(circle)
  })
}


function _container(){return(
function container() { 
  return `
<main role="main" class="container">
    <div class="row">
      <h4> Earthquakes in New Zealand</h4>
    </div>
    <div class='row'>
        <div class="col-6" id="earthquake-map"></div>
        <div class="col-6">
          <div id='magnitude-chart'>
           <h5> Number of Events by Magnitude </h5>
          </div>
            
          <div id='depth-chart'>
           <h5> Events by Depth (km) </h5>
          </div>
        </div>
    </div>
    <div class='row'>
      <div id='time-chart' class="single-col">
        <h5> Events per hour </h5>
      </div>
    </div>
    <table class="table table-hover" id="dc-table-graph">
        <thead>
            <tr class="header">
                <th>DTG</th>
                <th>Magnitude</th>
                <th>Depth</th>
                <th>Latitude</th>
                <th>Longitude</th>
            </tr>
        </thead>
    </table>
   <p>Earthquake data via <a href="https://quakesearch.geonet.org.nz/">Geonet</a>.</p>
  </main>
 `
}
)}

function _26(html){return(
html`<code>css</code> <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="https://unpkg.com/dc@4/dist/style/dc.css" />`
)}

function _27(htl){return(
htl.html`<code>leaflet css</code><link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
   integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
   crossorigin=""/>
   <style>
     #earthquake-map {
       width: 650px;
       height: 480px;
     }
   </style>`
)}

function _L(require){return(
require('leaflet@1.7.1')
)}

function _dc(require){return(
require('dc')
)}

function _crossfilter(require){return(
require('crossfilter2')
)}

function _d3(require){return(
require('d3')
)}

function _$(require){return(
require('jquery').then(jquery => {
  window.jquery = jquery;
  return require('popper@1.0.1/index.js').catch(() => jquery);
})
)}

function _bootstrap(require){return(
require('bootstrap')
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("buildvis")).define("buildvis", ["md","container","dc","width","dateDimension","format","d3","magnitudeDimension","magnitudeGroup","magnitudeScale","depthDimension","depthGroup","depthScale","hourDimension","hourGroup","hourScale"], _buildvis);
  main.variable(observer("dataset")).define("dataset", ["d3"], _dataset);
  main.variable(observer("facts")).define("facts", ["crossfilter","dataset"], _facts);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("dateDimension")).define("dateDimension", ["facts"], _dateDimension);
  main.variable(observer("format")).define("format", ["d3"], _format);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer("magnitudeDimension")).define("magnitudeDimension", ["facts"], _magnitudeDimension);
  main.variable(observer("magnitudeGroup")).define("magnitudeGroup", ["magnitudeDimension"], _magnitudeGroup);
  main.variable(observer("magnitudeScale")).define("magnitudeScale", ["d3","magnitudeDimension"], _magnitudeScale);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer("depthDimension")).define("depthDimension", ["facts"], _depthDimension);
  main.variable(observer("depthGroup")).define("depthGroup", ["depthDimension"], _depthGroup);
  main.variable(observer("depthScale")).define("depthScale", ["d3","depthDimension"], _depthScale);
  main.variable(observer()).define(["md"], _16);
  main.variable(observer("hourDimension")).define("hourDimension", ["facts","d3"], _hourDimension);
  main.variable(observer("hourGroup")).define("hourGroup", ["hourDimension"], _hourGroup);
  main.variable(observer("hourScale")).define("hourScale", ["d3","dataset"], _hourScale);
  main.variable(observer()).define(["md"], _20);
  main.variable(observer("map")).define("map", ["buildvis","L"], _map);
  main.variable(observer("circlesLayer")).define("circlesLayer", ["L","map"], _circlesLayer);
  main.variable(observer("mapMagnitudeScale")).define("mapMagnitudeScale", ["d3","magnitudeDimension"], _mapMagnitudeScale);
  main.variable(observer("circles")).define("circles", ["circlesLayer","dataset","L","mapMagnitudeScale","format"], _circles);
  main.variable(observer("container")).define("container", _container);
  main.variable(observer()).define(["html"], _26);
  main.variable(observer()).define(["htl"], _27);
  main.variable(observer("L")).define("L", ["require"], _L);
  main.variable(observer("dc")).define("dc", ["require"], _dc);
  main.variable(observer("crossfilter")).define("crossfilter", ["require"], _crossfilter);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("$")).define("$", ["require"], _$);
  main.variable(observer("bootstrap")).define("bootstrap", ["require"], _bootstrap);
  return main;
}
